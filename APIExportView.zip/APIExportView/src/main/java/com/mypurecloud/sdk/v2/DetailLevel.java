package com.mypurecloud.sdk.v2;

public enum DetailLevel {
    NONE,
    MINIMAL,
    HEADERS,
    FULL
}
